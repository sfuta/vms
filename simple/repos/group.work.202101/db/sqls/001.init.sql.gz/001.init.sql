-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: sample_rpg
-- ------------------------------------------------------
-- Server version	10.5.8-MariaDB-1:10.5.8+maria~focal

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equip_abilities`
--

DROP TABLE IF EXISTS `equip_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equip_abilities` (
  `player_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'プレイヤーID: mst_players.id',
  `ability_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'アビリティID: mst_abilities.id',
  PRIMARY KEY (`player_id`,`ability_id`),
  KEY `fk_equip_abilities_ability_id` (`ability_id`),
  CONSTRAINT `fk_equip_abilities_ability_id` FOREIGN KEY (`ability_id`) REFERENCES `mst_abilities` (`id`),
  CONSTRAINT `fk_equip_abilities_player_id` FOREIGN KEY (`player_id`) REFERENCES `mst_players` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='セットアビリティ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equip_abilities`
--

LOCK TABLES `equip_abilities` WRITE;
/*!40000 ALTER TABLE `equip_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `equip_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_abilities`
--

DROP TABLE IF EXISTS `mst_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_abilities` (
  `id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ID',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT 'アビリティ名',
  `job_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ジョブID: mst_jobs.id',
  `job_level` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ジョブレベル',
  `type` varchar(10) NOT NULL DEFAULT 'command' COMMENT 'アビリティのタイプ, command:コマンド, passive:パッシブ',
  `needs_ability_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '必要ABP',
  `detail` varchar(300) NOT NULL DEFAULT '' COMMENT '説明',
  PRIMARY KEY (`id`),
  KEY `fk_mst_abilities_job_id` (`job_id`),
  CONSTRAINT `fk_mst_abilities_job_id` FOREIGN KEY (`job_id`) REFERENCES `mst_jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='アビリティマスター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_abilities`
--

LOCK TABLES `mst_abilities` WRITE;
/*!40000 ALTER TABLE `mst_abilities` DISABLE KEYS */;
INSERT INTO `mst_abilities` VALUES (1,'かばう',2,1,'passive',10,'瀕死の味方をかばって代わりに攻撃を受ける'),(2,'守り',2,2,'command',30,'物理攻撃を0ダメージにする。次のコマンドを選択するまで有効'),(3,'両手持ち',2,3,'passive',50,'特定武器を両手で持つことで攻撃力2倍。盾は装備できなくなる。'),(4,'盾装備',2,4,'passive',100,'盾を装備できるようになる'),(5,'鎧装備',2,5,'passive',150,'鎧を装備できるようになる'),(6,'剣装備',2,6,'passive',350,'剣を装備できるようになる'),(7,'蹴り',3,0,'command',15,'敵全体に攻撃'),(8,'ためる',3,1,'command',15,'力を溜めて攻撃力2倍'),(9,'格闘',3,2,'passive',30,'素手での攻撃がモンクと同じダメージ計算式になる'),(10,'チャクラ',3,3,'command',45,'本人のHP回復、毒・暗闇を治療'),(11,'カウンター',3,4,'passive',60,'物理攻撃を受けると50%の確率で反撃する'),(12,'HP10%アップ',3,5,'passive',100,'最大HP10%アップ'),(13,'HP20%アップ',3,6,'passive',150,'最大HP20%アップ'),(14,'HP30%アップ',3,7,'passive',300,'最大HP30%アップ'),(15,'隠し通路',4,1,'passive',10,'隠し通路が見えるようになる'),(16,'とんずら',4,2,'command',20,'ボスなどの一部の敵を除き、必ず逃げられる'),(17,'ダッシュ',4,3,'passive',30,'キャンセルボタンを押しながら移動するとダッシュできる'),(18,'盗む',4,4,'command',50,'モンスターからアイテムを盗む'),(19,'警戒',4,5,'passive',75,'バックアタックを防ぐ'),(20,'ぶんどる',4,6,'command',150,'たたかう+盗む'),(21,'ちょこまか動く',4,7,'passive',300,'素早さが40になる'),(22,'ジャンプ',5,1,'command',50,'ジャンプ攻撃で槍を装備している場合はダメージ2倍'),(23,'竜剣',5,2,'command',150,'敵単体のHP・MPを吸収'),(24,'槍装備',5,3,'passive',400,'槍を装備できるようになる'),(25,'煙玉',6,1,'command',10,'ボスなどの一部の敵を除き、必ず逃げられる'),(26,'分身',6,2,'command',30,'物理攻撃を2回まで回避する分身を発生させる。'),(27,'先制攻撃',6,3,'passive',50,'先制攻撃の発生率が2倍になる'),(28,'投げる',6,4,'command',150,'アイテムを投げて攻撃する'),(29,'二刀流',6,5,'passive',450,'武器を2つ装備することができる'),(30,'みね打ち',7,1,'command',10,'たたかう+マヒ（しかしバグによりマヒ効果が無い）'),(31,'銭投げ',7,2,'command',30,'所持金を消費して敵全体を攻撃'),(32,'白刃取り',7,3,'passive',60,'25%の確率で物理攻撃を回避する'),(33,'刀装備',7,4,'passive',180,'刀を装備できるようになる'),(34,'居合抜き',7,5,'command',540,'敵全体に即死攻撃'),(35,'バーサク',8,1,'passive',100,'常にバーサク状態でコマンド入力できない'),(36,'斧装備',8,2,'passive',400,'斧を装備できるようになる'),(37,'動物',9,1,'command',15,'動物を呼び出してランダム効果'),(38,'狙う',9,2,'command',45,'必中でたたかう'),(39,'弓矢装備',9,3,'passive',135,'弓を装備できるようになる'),(40,'乱れ撃ち',9,4,'command',405,'対象ランダムで4回攻撃。1回あたりの攻撃力はたたかうの1/2'),(41,'魔法バリア',10,1,'passive',10,'瀕死状態になると自動でシェルが発動する'),(42,'魔法剣Lv1',10,2,'command',20,'レベル1までの魔法剣を使えるようになる'),(43,'魔法剣Lv2',10,3,'command',30,'レベル2までの魔法剣を使えるようになる'),(44,'魔法剣Lv3',10,4,'command',50,'レベル3までの魔法剣を使えるようになる'),(45,'魔法剣Lv4',10,5,'command',70,'レベル4までの魔法剣を使えるようになる'),(46,'魔法剣Lv5',10,6,'command',100,'レベル5までの魔法剣を使えるようになる'),(47,'魔法剣Lv6',10,7,'command',400,'レベル6までの魔法剣を使えるようになる'),(48,'白魔法Lv1',11,1,'command',10,'レベル1までの白魔法を使えるようになる'),(49,'白魔法Lv2',11,2,'command',20,'レベル2までの白魔法を使えるようになる'),(50,'白魔法Lv3',11,3,'command',30,'レベル3までの白魔法を使えるようになる'),(51,'白魔法Lv4',11,4,'command',50,'レベル4までの白魔法を使えるようになる'),(52,'白魔法Lv5',11,5,'command',70,'レベル5までの白魔法を使えるようになる'),(53,'白魔法Lv6',11,6,'command',100,'レベル6までの白魔法を使えるようになる'),(54,'MP10%アップ',11,7,'passive',300,'最大MP10%アップ'),(55,'黒魔法Lv1',12,1,'command',10,'レベル1までの黒魔法を使えるようになる'),(56,'黒魔法Lv2',12,2,'command',20,'レベル2までの黒魔法を使えるようになる'),(57,'黒魔法Lv3',12,3,'command',30,'レベル3までの黒魔法を使えるようになる'),(58,'黒魔法Lv4',12,4,'command',50,'レベル4までの黒魔法を使えるようになる'),(59,'黒魔法Lv5',12,5,'command',70,'レベル5までの黒魔法を使えるようになる'),(60,'黒魔法Lv6',12,6,'command',100,'レベル6までの黒魔法を使えるようになる'),(61,'MP30%アップ',12,7,'passive',450,'最大MP30%アップ'),(62,'時空Lv1',13,1,'command',10,'レベル1までの時空魔法を使えるようになる'),(63,'時空Lv2',13,2,'command',20,'レベル2までの時空魔法を使えるようになる'),(64,'時空Lv3',13,3,'command',30,'レベル3までの時空魔法を使えるようになる'),(65,'時空Lv4',13,4,'command',50,'レベル4までの時空魔法を使えるようになる'),(66,'時空Lv5',13,5,'command',70,'レベル5までの時空魔法を使えるようになる'),(67,'時空Lv6',13,6,'command',100,'レベル6までの時空魔法を使えるようになる'),(68,'ロッド装備',13,7,'passive',250,'ロッド、杖を装備できるようになる'),(69,'召喚Lv1',14,1,'command',15,'レベル1までの召喚魔法を使えるようになる'),(70,'召喚Lv2',14,2,'command',30,'レベル2までの召喚魔法を使えるようになる'),(71,'召喚Lv3',14,3,'command',45,'レベル3までの召喚魔法を使えるようになる'),(72,'召喚Lv4',14,4,'command',60,'レベル4までの召喚魔法を使えるようになる'),(73,'召喚Lv5',14,5,'command',100,'レベル5までの召喚魔法を使えるようになる'),(74,'呼び出す',14,6,'command',500,'MP消費0で、習得した召喚獣をランダムで召喚'),(75,'調べる',15,1,'command',10,'敵単体のHPを調べる'),(76,'ラーニング',15,2,'passive',20,'モンスターの特殊攻撃を受けて覚える'),(77,'青魔法',15,3,'command',70,'青魔法を使えるようになる'),(78,'見破る',15,4,'command',250,'敵単体のLv、HP、弱点、状態を調べる'),(79,'白黒魔Lv1',16,1,'command',20,'レベル1までの白魔法・黒魔法を使えるようになる'),(80,'白黒魔Lv2',16,2,'command',40,'レベル2までの白魔法・黒魔法を使えるようになる'),(81,'白黒魔Lv3',16,3,'command',100,'レベル3までの白魔法・黒魔法を使えるようになる'),(82,'連続魔',16,4,'command',999,'青魔法以外の魔法を2連続で使用できる'),(83,'なだめる',17,1,'command',10,'ストップ状態にする'),(84,'操る',17,2,'command',50,'敵を操作できるようになる'),(85,'鞭装備',17,3,'passive',100,'鞭を装備できるようになる'),(86,'とらえる',17,4,'command',300,'HPが最大HPの1/8以下の敵を捕らえる。「とらえる」で敵を捕らえた状態の時にコマンド選択可能'),(87,'薬の知識',18,1,'passive',15,'回復アイテムの回復量が2倍になる'),(88,'調合',18,2,'command',30,'2つの消費アイテムを使用して特殊な効果が発生する'),(89,'飲む',18,3,'command',45,'以下の飲む専用アイテムが使用可能になる'),(90,'治癒',18,4,'command',135,'味方全員の状態異常治療'),(91,'蘇生',18,5,'command',405,'味方全員を最大HPの1/16・MP全快の状態で復活'),(92,'地形',19,1,'command',25,'戦闘中の地形に応じた効果が発生'),(93,'落とし穴回避',19,2,'passive',50,'手前に落とし穴があると立ち止まり、落とし穴が表示される'),(94,'ダメージ床',19,3,'passive',100,'ダメージ床のダメージを受けなくなる'),(95,'隠れる',20,1,'command',25,'画面外に消え、攻撃対象から外れる。「かくれる」で隠れた状態の時にコマンド選択可能'),(96,'竪琴装備',20,2,'passive',50,'竪琴を装備できるようになる'),(97,'歌う',20,3,'command',100,'歌を使えるようになる'),(98,'色目',21,1,'command',25,'敵単体の行動を一回封じる'),(99,'踊る',21,2,'command',50,'4種の踊りからランダムで発動'),(100,'リボン装備',21,3,'passive',325,'リボン、レインボードレス、赤い靴を装備できるようになる'),(101,'ものまね',22,1,'command',999,'直前に行動した味方と同じ行動をする'),(102,'たたかう',1,0,'command',0,'通常攻撃を行う'),(103,'アイテム',1,0,'command',0,'所持アイテムを使用する');
/*!40000 ALTER TABLE `mst_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_default_equip_abilities`
--

DROP TABLE IF EXISTS `mst_default_equip_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_default_equip_abilities` (
  `job_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ジョブID: mst_jobs.id',
  `ability_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'アビリティID: mst_abilities.id',
  PRIMARY KEY (`job_id`,`ability_id`),
  KEY `fk_mst_default_equip_abilities_ability_id` (`ability_id`),
  CONSTRAINT `fk_mst_default_equip_abilities_ability_id` FOREIGN KEY (`ability_id`) REFERENCES `mst_abilities` (`id`),
  CONSTRAINT `fk_mst_default_equip_abilities_job_id` FOREIGN KEY (`job_id`) REFERENCES `mst_jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ジョブ別初期設定アビリティ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_default_equip_abilities`
--

LOCK TABLES `mst_default_equip_abilities` WRITE;
/*!40000 ALTER TABLE `mst_default_equip_abilities` DISABLE KEYS */;
INSERT INTO `mst_default_equip_abilities` VALUES (1,102),(1,103),(2,1),(2,2),(2,3),(2,102),(2,103),(3,7),(3,8),(3,9),(3,11),(3,102),(3,103),(4,15),(4,17),(4,18),(4,19),(4,102),(4,103),(5,22),(5,102),(5,103),(6,27),(6,28),(6,29),(6,102),(6,103),(7,31),(7,32),(7,102),(7,103),(8,35),(8,102),(8,103),(9,38),(9,102),(9,103),(10,41),(10,47),(10,102),(10,103),(11,53),(11,102),(11,103),(12,60),(12,102),(12,103),(13,67),(13,102),(13,103),(14,73),(14,102),(14,103),(15,76),(15,77),(15,102),(15,103),(16,81),(16,102),(16,103),(17,86),(17,102),(17,103),(18,87),(18,89),(18,102),(18,103),(19,92),(19,93),(19,94),(19,102),(19,103),(20,97),(20,102),(20,103),(21,99),(21,102),(21,103),(22,101);
/*!40000 ALTER TABLE `mst_default_equip_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_jobs`
--

DROP TABLE IF EXISTS `mst_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_jobs` (
  `id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'id',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT 'ジョブ名',
  `detail` varchar(300) NOT NULL DEFAULT '' COMMENT 'ジョブ説明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ジョブマスター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_jobs`
--

LOCK TABLES `mst_jobs` WRITE;
/*!40000 ALTER TABLE `mst_jobs` DISABLE KEYS */;
INSERT INTO `mst_jobs` VALUES (1,'すっぴん','全ての武器・防具を装備可能'),(2,'ナイト','瀕死の味方をかばう'),(3,'モンク','格闘攻撃。カウンター攻撃'),(4,'シーフ','ダッシュ、隠し通路発見、警戒'),(5,'竜騎士',''),(6,'忍者','先制攻撃しやすい、二刀流'),(7,'侍','白刃取り'),(8,'バーサーカー','常にバーサク状態でコマンド入力不可'),(9,'狩人',''),(10,'魔法剣士','瀕死で魔法バリア発動'),(11,'白魔道士','回復系魔法を使用可能'),(12,'黒魔道士','攻撃系魔法を使用可能'),(13,'時魔道士',''),(14,'召喚士',''),(15,'青魔道士','モンスターの特殊攻撃をラーニング'),(16,'赤魔道士',''),(17,'魔獣使い',''),(18,'薬師','ポーション、エーテルの回復量2倍'),(19,'風水士','落とし穴発見、ダメージ床無効'),(20,'吟遊詩人',''),(21,'踊り子',''),(22,'ものまねし','');
/*!40000 ALTER TABLE `mst_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_levels`
--

DROP TABLE IF EXISTS `mst_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_levels` (
  `level` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Lv',
  `needs_experience_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '必要経験値',
  PRIMARY KEY (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lvマスター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_levels`
--

LOCK TABLES `mst_levels` WRITE;
/*!40000 ALTER TABLE `mst_levels` DISABLE KEYS */;
INSERT INTO `mst_levels` VALUES (1,0),(2,10),(3,33),(4,74),(5,140),(6,241),(7,389),(8,599),(9,888),(10,1276),(11,1786),(12,2441),(13,3269),(14,4299),(15,5564),(16,7097),(17,8936),(18,11120),(19,13691),(20,16693),(21,20173),(22,24180),(23,28765),(24,33983),(25,39890),(26,46546),(27,54012),(28,62352),(29,71632),(30,81921),(31,93291),(32,105815),(33,119569),(34,134633),(35,151087),(36,169015),(37,188503),(38,209640),(39,232517),(40,257227),(41,283867),(42,312534),(43,343330),(44,376357),(45,411722),(46,449533),(47,489900),(48,532937),(49,578759),(50,627485),(51,679235),(52,734131),(53,792300),(54,853869),(55,918969),(56,987732),(57,1060294),(58,1136793),(59,1217368),(60,1302163),(61,1391323),(62,1484995),(63,1583329),(64,1686478),(65,1794597),(66,1907843),(67,2026376),(68,2150358),(69,2279955),(70,2415333),(71,2556663),(72,2704116),(73,2857867),(74,3018093),(75,3184974),(76,3358692),(77,3539432),(78,3727380),(79,3922726),(80,4125661),(81,4336381),(82,4555081),(83,4781961),(84,5017223),(85,5261071),(86,5513712),(87,5775354),(88,6046210),(89,6326493),(90,6616420),(91,6916210),(92,7226084),(93,7546266),(94,7876982),(95,8218461),(96,8570934),(97,8934635),(98,9309800),(99,9696668);
/*!40000 ALTER TABLE `mst_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_players`
--

DROP TABLE IF EXISTS `mst_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_players` (
  `id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ID',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT 'プレイヤー名',
  `job_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '現在のジョブID: mst_jobs.id',
  `experience_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '取得した経験値',
  `profile` varchar(300) NOT NULL DEFAULT '' COMMENT 'プロフィール',
  PRIMARY KEY (`id`),
  KEY `fk_mst_players_job_id` (`job_id`),
  CONSTRAINT `fk_mst_players_job_id` FOREIGN KEY (`job_id`) REFERENCES `mst_jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プレイヤーマスター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_players`
--

LOCK TABLES `mst_players` WRITE;
/*!40000 ALTER TABLE `mst_players` DISABLE KEYS */;
INSERT INTO `mst_players` VALUES (1,'Butz',3,88050,'チョコボのボコと共に世界を旅する青年。20歳、176cm 58kg'),(2,'Lenna',1,89332,'タイクーン王国第二王女。19歳、161cm 45kg'),(3,'Faris',3,88230,'海賊のお頭。20歳、172cm 53kg,男装をしているが実はタイクーン王国第一王女であり、レナの姉。'),(4,'Galuf',2,89232,'記憶喪失の老人。60歳、168cm 64kg, 正体は第二世界のバル城城主'),(5,'Krile',3,89232,'ガラフの孫娘。14歳、154cm 40kg');
/*!40000 ALTER TABLE `mst_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_jobs`
--

DROP TABLE IF EXISTS `player_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_jobs` (
  `player_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'プレイヤーID: mst_players.id',
  `job_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'ジョブID: mst_jobs.id',
  `current_job_level` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '現在のジョブレベル',
  `current_ability_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '取得ABP',
  PRIMARY KEY (`player_id`,`job_id`),
  KEY `fk_player_jobs_job_id` (`job_id`),
  CONSTRAINT `fk_player_jobs_job_id` FOREIGN KEY (`job_id`) REFERENCES `mst_abilities` (`id`),
  CONSTRAINT `fk_player_jobs_player_id` FOREIGN KEY (`player_id`) REFERENCES `mst_players` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プレイヤー別ジョブレベル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_jobs`
--

LOCK TABLES `player_jobs` WRITE;
/*!40000 ALTER TABLE `player_jobs` DISABLE KEYS */;
INSERT INTO `player_jobs` VALUES (1,1,1,0),(1,2,1,20),(1,3,1,20),(1,4,1,20),(1,5,1,20),(1,6,1,20),(1,7,1,20),(1,8,1,20),(1,9,1,20),(1,10,1,20),(1,11,1,20),(1,12,1,20),(1,13,1,20),(1,14,1,20),(1,15,1,20),(1,16,1,20),(1,17,1,20),(1,18,1,20),(1,19,1,20),(1,20,1,20),(1,21,1,20),(1,22,1,20),(2,1,1,0),(2,2,1,20),(2,3,1,20),(2,4,1,20),(2,5,1,20),(2,6,1,20),(2,7,1,20),(2,8,1,20),(2,9,1,20),(2,10,1,20),(2,11,1,20),(2,12,1,20),(2,13,1,20),(2,14,1,20),(2,15,1,20),(2,16,1,20),(2,17,1,20),(2,18,1,20),(2,19,1,20),(2,20,1,20),(2,21,1,20),(2,22,1,20),(3,1,1,0),(3,2,1,20),(3,3,1,20),(3,4,1,20),(3,5,1,20),(3,6,1,20),(3,7,1,20),(3,8,1,20),(3,9,1,20),(3,10,1,20),(3,11,1,20),(3,12,1,20),(3,13,1,20),(3,14,1,20),(3,15,1,20),(3,16,1,20),(3,17,1,20),(3,18,1,20),(3,19,1,20),(3,20,1,20),(3,21,1,20),(3,22,1,20),(4,1,1,0),(4,2,1,20),(4,3,1,20),(4,4,1,20),(4,5,1,20),(4,6,1,20),(4,7,1,20),(4,8,1,20),(4,9,1,20),(4,10,1,20),(4,11,1,20),(4,12,1,20),(4,13,1,20),(4,14,1,20),(4,15,1,20),(4,16,1,20),(4,17,1,20),(4,18,1,20),(4,19,1,20),(4,20,1,20),(4,21,1,20),(4,22,1,20),(5,1,1,0),(5,2,1,20),(5,3,1,20),(5,4,1,20),(5,5,1,20),(5,6,1,20),(5,7,1,20),(5,8,1,20),(5,9,1,20),(5,10,1,20),(5,11,1,20),(5,12,1,20),(5,13,1,20),(5,14,1,20),(5,15,1,20),(5,16,1,20),(5,17,1,20),(5,18,1,20),(5,19,1,20),(5,20,1,20),(5,21,1,20),(5,22,1,20);
/*!40000 ALTER TABLE `player_jobs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-23  9:28:57
